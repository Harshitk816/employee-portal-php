const addButton = document.getElementById('add-btn');
const removeButton = document.getElementById('remove-btn');
let inputElements = [];

addButton.addEventListener('click', addInputElement);
removeButton.addEventListener('click', removeInputElement);

function removeInputElement(){
    if (inputElements.length > 0) {
        document.getElementById('hobbies').removeChild(inputElements[inputElements.length -1]);
        inputElements.pop();
    }
};

function addInputElement() {
    if(inputElements.length<4){
        const inputElement = document.createElement('input');
        inputElement.type = 'text';
        inputElement.style.width = '10px';
        inputElement.required=true;
        inputElement.name='hobbies[]';
        inputElement.classList.add('form-control')

        const removeElement = document.createElement('button');
        document.getElementById('hobbies').appendChild(inputElement);
        inputElements.push(inputElement);

    }
}